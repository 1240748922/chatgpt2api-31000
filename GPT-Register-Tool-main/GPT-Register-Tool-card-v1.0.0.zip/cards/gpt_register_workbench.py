"""GPT-Register-Tool adapter card for the operations toolbox.

The card owns only the PyQt6 presentation layer. The registration, mailbox,
account, and payment logic remains in the source project's Python backend and
is executed as a child process so the toolbox stays responsive.
"""

from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

from PyQt6.QtCore import QProcess, QProcessEnvironment, Qt
from PyQt6.QtWidgets import (
    QFileDialog,
    QFormLayout,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPlainTextEdit,
    QComboBox,
    QPushButton,
    QSpinBox,
    QVBoxLayout,
    QWidget,
)


CARD_NAME = "GPT 账号工作台"
CARD_ICON = "◎"
CARD_ORDER = 45

TOOLBOX_ROOT = Path.home() / "Documents" / "脑图运维工具箱"
CARD_CONFIG_DIR = TOOLBOX_ROOT / "config" / "gpt_register"
CARD_CONFIG_FILE = CARD_CONFIG_DIR / "settings.json"
DEFAULT_PROJECT_ROOT = Path.home() / "Downloads" / "GPT-Register-Tool-main"


def _load_settings() -> dict:
    try:
        with CARD_CONFIG_FILE.open("r", encoding="utf-8") as file_obj:
            value = json.load(file_obj)
        return value if isinstance(value, dict) else {}
    except (OSError, ValueError):
        return {}


def _save_settings(value: dict) -> None:
    CARD_CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    with CARD_CONFIG_FILE.open("w", encoding="utf-8") as file_obj:
        json.dump(value, file_obj, ensure_ascii=False, indent=2)


def _default_python(project_root: Path) -> str:
    candidate = project_root / ".venv" / "Scripts" / "python.exe"
    return str(candidate if candidate.exists() else "python")


class GptRegisterWorkbenchCard(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("GptRegisterWorkbenchCard")
        self.process: QProcess | None = None
        self.settings = _load_settings()
        self._build_ui()
        self._load_form_values()

    def _build_ui(self) -> None:
        self.setStyleSheet(
            """
            #GptRegisterWorkbenchCard { background: #F7F7F8; }
            #GptRegisterWorkbenchCard QLabel { color: #2B2F36; }
            #GptRegisterWorkbenchCard QLineEdit,
            #GptRegisterWorkbenchCard QComboBox,
            #GptRegisterWorkbenchCard QSpinBox,
            #GptRegisterWorkbenchCard QPlainTextEdit {
                background: #FFFFFF; border: 1px solid #C9CDD3;
                border-radius: 7px; color: #20242A; padding: 7px 9px;
            }
            #GptRegisterWorkbenchCard QLineEdit:focus,
            #GptRegisterWorkbenchCard QComboBox:focus,
            #GptRegisterWorkbenchCard QSpinBox:focus {
                border: 1px solid #C4513F;
            }
            #PrimaryAction {
                background: #C4513F; border: 1px solid #A94334;
                border-radius: 7px; color: #FFFFFF; font-weight: 800;
                padding: 9px 18px;
            }
            #PrimaryAction:disabled { background: #D9A69D; border-color: #D9A69D; }
            #StopAction {
                background: #FFF0EE; border: 1px solid #F3C8C2;
                border-radius: 7px; color: #BB3628; font-weight: 700;
                padding: 9px 18px;
            }
            #Status { color: #147D59; background: #E9F7F1; border-radius: 10px; padding: 5px 11px; font-weight: 700; }
            """
        )

        root = QVBoxLayout(self)
        root.setContentsMargins(22, 18, 22, 20)
        root.setSpacing(12)

        header = QHBoxLayout()
        title_block = QVBoxLayout()
        title = QLabel("GPT 账号工作台")
        title.setStyleSheet("font-size: 20px; font-weight: 800;")
        subtitle = QLabel("复用 GPT-Register-Tool 后端的卡片化操作入口")
        subtitle.setStyleSheet("color: #7A828E; font-size: 12px;")
        title_block.addWidget(title)
        title_block.addWidget(subtitle)
        header.addLayout(title_block)
        header.addStretch()
        self.status_label = QLabel("就绪")
        self.status_label.setObjectName("Status")
        header.addWidget(self.status_label)
        root.addLayout(header)

        workspace = QGridLayout()
        workspace.setHorizontalSpacing(12)
        workspace.setVerticalSpacing(10)

        paths_box = QGroupBox("运行环境")
        paths_form = QFormLayout(paths_box)
        self.project_edit = QLineEdit()
        self.project_edit.setToolTip("包含 chatgpt_phone_reg.py 和 sms_tool 的项目目录")
        project_row = QHBoxLayout()
        project_row.addWidget(self.project_edit)
        project_button = QPushButton("选择")
        project_button.clicked.connect(self._choose_project)
        project_row.addWidget(project_button)
        paths_form.addRow("项目目录", project_row)

        self.python_edit = QLineEdit()
        python_row = QHBoxLayout()
        python_row.addWidget(self.python_edit)
        python_button = QPushButton("选择")
        python_button.clicked.connect(self._choose_python)
        python_row.addWidget(python_button)
        paths_form.addRow("Python 解释器", python_row)

        self.operation_combo = QComboBox()
        self.operation_combo.addItem("环境诊断", "doctor")
        self.operation_combo.addItem("批量邮箱注册", "register")
        self.operation_combo.addItem("刷新本地额度", "quota")
        self.operation_combo.addItem("重建 SQLite 账号索引", "rebuild")
        self.operation_combo.addItem("列出支付方式", "payment_methods")
        self.operation_combo.addItem("列出 PayPal 链接", "paypal_links")
        self.operation_combo.addItem("提取支付链接", "payment")
        self.operation_combo.currentIndexChanged.connect(self._refresh_operation_state)
        paths_form.addRow("操作", self.operation_combo)
        workspace.addWidget(paths_box, 0, 0)

        task_box = QGroupBox("任务参数")
        task_form = QFormLayout(task_box)
        self.count_spin = QSpinBox()
        self.count_spin.setRange(1, 10000)
        self.count_spin.setValue(1)
        task_form.addRow("注册数量", self.count_spin)
        self.workers_spin = QSpinBox()
        self.workers_spin.setRange(1, 64)
        self.workers_spin.setValue(1)
        task_form.addRow("并发数", self.workers_spin)
        self.mailbox_edit = QLineEdit()
        mailbox_row = QHBoxLayout()
        mailbox_row.addWidget(self.mailbox_edit)
        mailbox_button = QPushButton("选择")
        mailbox_button.clicked.connect(self._choose_mailbox)
        mailbox_row.addWidget(mailbox_button)
        task_form.addRow("邮箱池文件", mailbox_row)
        self.proxy_edit = QLineEdit()
        self.proxy_edit.setPlaceholderText("可留空；支持一行一个代理")
        task_form.addRow("注册代理池", self.proxy_edit)
        self.payment_combo = QComboBox()
        self.payment_combo.addItems(["paypal", "gopay", "gcash", "grabpay", "upi", "momo"])
        task_form.addRow("支付方式", self.payment_combo)
        self.session_edit = QLineEdit()
        session_row = QHBoxLayout()
        session_row.addWidget(self.session_edit)
        session_button = QPushButton("选择")
        session_button.clicked.connect(self._choose_session)
        session_row.addWidget(session_button)
        task_form.addRow("会话文件", session_row)
        workspace.addWidget(task_box, 0, 1)
        root.addLayout(workspace)

        actions = QHBoxLayout()
        self.start_button = QPushButton("运行操作")
        self.start_button.setObjectName("PrimaryAction")
        self.start_button.clicked.connect(self._start)
        self.stop_button = QPushButton("停止")
        self.stop_button.setObjectName("StopAction")
        self.stop_button.setEnabled(False)
        self.stop_button.clicked.connect(self._stop)
        self.clear_button = QPushButton("清空日志")
        self.clear_button.clicked.connect(lambda: self.log_edit.clear())
        actions.addWidget(self.start_button)
        actions.addWidget(self.stop_button)
        actions.addWidget(self.clear_button)
        actions.addStretch()
        root.addLayout(actions)

        self.log_edit = QPlainTextEdit()
        self.log_edit.setReadOnly(True)
        self.log_edit.setPlaceholderText("任务输出会显示在这里")
        root.addWidget(self.log_edit, 1)

    def _load_form_values(self) -> None:
        project = Path(self.settings.get("project_root", str(DEFAULT_PROJECT_ROOT)))
        self.project_edit.setText(str(project))
        self.python_edit.setText(self.settings.get("python_path", _default_python(project)))
        self.count_spin.setValue(max(1, int(self.settings.get("count", 1))))
        self.workers_spin.setValue(max(1, int(self.settings.get("workers", 1))))
        self.mailbox_edit.setText(str(self.settings.get("mailbox_file", "")))
        self.proxy_edit.setText(str(self.settings.get("proxy_pool", "")))
        self.payment_combo.setCurrentText(str(self.settings.get("payment_method", "paypal")))
        self.session_edit.setText(str(self.settings.get("session_file", "")))
        self._refresh_operation_state()

    def _save_form_values(self) -> None:
        _save_settings(
            {
                "project_root": self.project_edit.text().strip(),
                "python_path": self.python_edit.text().strip(),
                "count": self.count_spin.value(),
                "workers": self.workers_spin.value(),
                "mailbox_file": self.mailbox_edit.text().strip(),
                "proxy_pool": self.proxy_edit.text(),
                "payment_method": self.payment_combo.currentText(),
                "session_file": self.session_edit.text().strip(),
            }
        )

    def _refresh_operation_state(self) -> None:
        is_register = self.operation_combo.currentData() == "register"
        self.count_spin.setEnabled(is_register)
        self.workers_spin.setEnabled(is_register)
        self.mailbox_edit.setEnabled(is_register)
        self.proxy_edit.setEnabled(is_register)
        is_payment = self.operation_combo.currentData() == "payment"
        self.payment_combo.setEnabled(is_payment)
        self.session_edit.setEnabled(is_payment)

    def _choose_project(self) -> None:
        path = QFileDialog.getExistingDirectory(self, "选择 GPT-Register-Tool 项目目录", self.project_edit.text())
        if path:
            self.project_edit.setText(path)
            if not self.python_edit.text() or self.python_edit.text() == "python":
                self.python_edit.setText(_default_python(Path(path)))

    def _choose_python(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "选择 Python 解释器", self.python_edit.text(), "Python (*.exe);;所有文件 (*)")
        if path:
            self.python_edit.setText(path)

    def _choose_mailbox(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "选择邮箱池文件", self.mailbox_edit.text(), "文本文件 (*.txt *.json *.jsonl);;所有文件 (*)")
        if path:
            self.mailbox_edit.setText(path)

    def _choose_session(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "选择会话文件", self.session_edit.text(), "JSON 文件 (*.json);;所有文件 (*)")
        if path:
            self.session_edit.setText(path)

    def _build_arguments(self) -> tuple[Path, list[str]]:
        project = Path(self.project_edit.text().strip()).expanduser()
        script = project / "chatgpt_phone_reg.py"
        operation = self.operation_combo.currentData()
        args = [str(script)]
        if operation == "doctor":
            args.extend(["--doctor", "--json"])
        elif operation == "register":
            args.extend(["--count", str(self.count_spin.value()), "--workers", str(self.workers_spin.value())])
            if self.mailbox_edit.text().strip():
                args.extend(["--mailbox-file", self.mailbox_edit.text().strip()])
            if self.proxy_edit.text().strip():
                args.extend(["--proxy-pool", self.proxy_edit.text().strip()])
        elif operation == "quota":
            args.append("--refresh-local-quota")
        elif operation == "rebuild":
            args.append("--rebuild-sqlite")
        elif operation == "payment_methods":
            args.append("--list-payment-methods")
        elif operation == "paypal_links":
            args.append("--list-paypal-links")
        elif operation == "payment":
            args.extend(["--extract-payment-link", "--payment-method", self.payment_combo.currentText()])
            if self.session_edit.text().strip():
                args.extend(["--session-file", self.session_edit.text().strip()])
        return project, args

    def _start(self) -> None:
        if self.process is not None:
            return
        try:
            project, args = self._build_arguments()
        except Exception as exc:
            QMessageBox.warning(self, "参数错误", str(exc))
            return
        python_path = self.python_edit.text().strip() or "python"
        script = Path(args[0])
        if not project.is_dir() or not script.is_file():
            QMessageBox.warning(self, "项目目录无效", f"未找到后端入口：\n{script}")
            return
        if os.path.isabs(python_path) and not Path(python_path).is_file():
            QMessageBox.warning(self, "Python 路径无效", f"未找到解释器：\n{python_path}")
            return

        self._save_form_values()
        self.log_edit.appendPlainText(f"$ {python_path} {' '.join(args)}")
        self.status_label.setText("运行中")
        self.start_button.setEnabled(False)
        self.stop_button.setEnabled(True)
        self.process = QProcess(self)
        self.process.setProgram(python_path)
        self.process.setArguments(args)
        self.process.setWorkingDirectory(str(project))
        environment = QProcessEnvironment.systemEnvironment()
        environment.insert("PYTHONUNBUFFERED", "1")
        self.process.setProcessEnvironment(environment)
        self.process.readyReadStandardOutput.connect(self._read_stdout)
        self.process.readyReadStandardError.connect(self._read_stderr)
        self.process.finished.connect(self._finished)
        self.process.errorOccurred.connect(self._process_error)
        self.process.start()

    def _read_stdout(self) -> None:
        if self.process is None:
            return
        text = bytes(self.process.readAllStandardOutput()).decode("utf-8", "replace")
        if text:
            self.log_edit.appendPlainText(text.rstrip())

    def _read_stderr(self) -> None:
        if self.process is None:
            return
        text = bytes(self.process.readAllStandardError()).decode("utf-8", "replace")
        if text:
            self.log_edit.appendPlainText("[stderr] " + text.rstrip())

    def _process_error(self, error) -> None:
        if self.process is not None:
            self.log_edit.appendPlainText(f"[process error] {self.process.errorString()}")

    def _finished(self, exit_code: int, _exit_status) -> None:
        self._read_stdout()
        self._read_stderr()
        self.log_edit.appendPlainText(f"\n任务结束，退出码：{exit_code}")
        self.status_label.setText("完成" if exit_code == 0 else "失败")
        self.start_button.setEnabled(True)
        self.stop_button.setEnabled(False)
        if self.process is not None:
            self.process.deleteLater()
            self.process = None

    def _stop(self) -> None:
        if self.process is None:
            return
        self.status_label.setText("正在停止")
        self.process.terminate()
        if not self.process.waitForFinished(1500):
            self.process.kill()


def create_card(parent=None):
    return GptRegisterWorkbenchCard(parent)
